# pypi-package

Aprendendo a criar um pacote instalável via pip.

**Disciplina:** Desenvolvimento Aberto

**Repositório da Disciplina:** [https://github.com/Insper/dev-aberto](https://github.com/Insper/dev-aberto)